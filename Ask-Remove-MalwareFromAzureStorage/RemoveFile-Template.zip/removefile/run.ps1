using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

# Interact with query parameters or the body of the request.
#$name = $Request.Query.Name

#Write-Host "Request"
#$Request

#Write-Host "RequestQuery"
#$Request.Query

#Write-Host "TriggerMetaData"
#$TriggerMetadata

#variable for storage account name
$storageaccount = $TriggerMetadata.compromisedEntity

#variable for storage account share
$share = ($TriggerMetadata.extendedProperties).'file share'

#variable for malware file
$file = ($TriggerMetadata.extendedProperties).file

#Filter through entities and find storage account resource id
$azurestorageresource = $Request.Body.Entities | Where-Object {$_.Type -eq "azure-resource"}

#variable for storage account resource group
$storerg = ($azurestorageresource.ResourceId).split('/')[4]

#Obtain storage account key and build storage context
$key = Get-AzStorageAccountKey -ResourceGroupName $storerg -Name $storageaccount 
$Context = New-AzStorageContext -StorageAccountName $storageaccount -StorageAccountKey $key[0].Value

#Remove malware file
Remove-AzStorageFile -ShareName $share -Path $file -Context $Context